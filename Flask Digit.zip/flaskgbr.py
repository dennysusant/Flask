from flask import Flask, abort, jsonify, render_template,url_for, request,send_from_directory,redirect
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
from sklearn import linear_model
from sklearn.datasets import load_digits
import joblib
from werkzeug.utils import secure_filename
from PIL import Image
import PIL.ImageOps

app=Flask(__name__)


@app.route('/file/<path:path>')
def aksesFile(path):
    return send_from_directory ('file',path)

app.config['UPLOAD_FOLDER']='./file'
@app.route('/')
def home():
    return render_template('upload.html')

@app.route('/upload', methods=['GET','POST'])
def upload():
    if request.method=='POST':
        gbr=Image.open(request.files['file']).convert('L')
        gbr=gbr.resize((8,8))
        filex = np.random.rand(1)
        gbr=PIL.ImageOps.invert(gbr)
        gbrArr=np.array(gbr)
        prediksi=model.predict(gbrArr.reshape(1,-1))
        plt.imshow(gbrArr,cmap='gray')
        plt.title(
            'P={}'.format(prediksi)
            )
        plt.savefig('./file/{}.png'.format(filex))
        return render_template('baca.html',x='{}.png'.format(filex))



if __name__=='__main__':
    model=joblib.load('digits.joblib')
    app.run(debug=True)